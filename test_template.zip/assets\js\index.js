console.log('Test Landing Page Loaded');

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    
    const heading = document.querySelector('h1');
    if (heading) {
        heading.style.transition = 'color 0.3s';
        heading.addEventListener('mouseenter', function() {
            this.style.color = '#1d4ed8';
        });
        heading.addEventListener('mouseleave', function() {
            this.style.color = '#2563eb';
        });
    }
});
