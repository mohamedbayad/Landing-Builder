---
name: conversion-copywriting
description: Generates persuasive, benefit-driven landing page copy using direct-response marketing principles.
---

# Conversion Copywriting

Generate landing page copy that sounds like it was written by a professional direct-response marketer. Produces **persuasive, conversion-focused content** instead of generic product descriptions.

Works for any product category: gadgets, automotive, fashion, handmade, beauty, home, health, lifestyle.

---

## When to use this skill

- When writing headline, sub-headline, and CTA copy for a landing page
- When translating product features into customer benefits
- When crafting testimonials, FAQ answers, or offer stack copy
- When the existing copy feels generic, robotic, or feature-focused instead of benefit-driven

## How to use it

### Core Rule

People do not buy products. They buy relief from problems, convenience, safety, comfort, confidence, and time saved. The copy must focus on **why the product matters**, not just what it is.

### Landing Page Persuasion Structure

Follow this section-by-section approach:

**1. Hero Promise** — Answer "Why should I care?" immediately.
- Headline: Strong promise or transformation
- Sub-headline: What the product does and why it matters
- CTA: Action-focused verb

**2. Problem Visualization** — Show the real-life frustration without the product (inconvenience, wasted time, unsafe situations, discomfort).

**3. Solution Introduction** — Introduce the product focusing on simplicity, speed, reliability, convenience.

**4. Feature → Benefit Translation** — Never present features alone. Always translate:
- Feature = what it has
- Benefit = why it matters

**5. Real Life Use Cases** — Help the reader imagine themselves using the product (travel, emergencies, home, outdoor, family).

**6. Social Proof** — Testimonials must include: scenario, benefit, emotional reaction.

**7. Offer Stack** — Explain value clearly: price, what's included, guarantee, bonuses, shipping.

**8. FAQ** — Answer objections: ease of use, compatibility, durability, warranty.

### Tone Rules

- Human, confident, helpful, clear
- Avoid robotic language and generic marketing filler

---

## Examples

### Example 1 — Hero Copy (Gadget)

**Input:** Portable tire inflator, 120 PSI  
**Output:**
```
Headline: Never Get Stranded With a Flat Tire Again.
Sub-headline: A compact air compressor that inflates your tires in minutes — wherever you are.
CTA: Get Yours Today
```

### Example 2 — Feature → Benefit Translation

**Input:** Feature: "120 PSI compressor"  
**Output:**
```
Feature: 120 PSI Compressor
Benefit: Inflate your car tire in minutes without visiting a gas station.
```

### Example 3 — Testimonial (Story-Driven)

**Input:** Customer used the inflator during a roadside emergency  
**Output:**
```
"This saved me when my tire went flat at night on a back road.
Took less than five minutes. I keep it in my trunk everywhere I go."
— Sarah M., Verified Buyer
```

---

## Constraints

- **Do NOT** write headlines in ALL CAPS — use sentence case or title case
- **Do NOT** present features without translating them into benefits
- **Do NOT** write generic testimonials ("Great product!") — every testimonial needs a scenario + benefit
- **Do NOT** use filler phrases ("revolutionary", "game-changing", "best-in-class")
- **Do NOT** skip the offer stack — always explain what's included and the guarantee
- **ALWAYS** include a CTA in hero, mid-page, and final offer
