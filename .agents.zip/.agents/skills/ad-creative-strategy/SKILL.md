---
name: ad-creative-strategy
description: Builds high-converting ad creatives and landing page visuals from a Product Profile — covering image strategy, photorealistic product integration, hook visuals, angle prioritization, creative variations, and validation.
---

# Ad Creative Strategy

Build a complete **ad-creative system** that turns marketing intelligence into scroll-stopping, conversion-driving visuals. This skill bridges the gap between strategy (what to say) and execution (what to show).

> **Prerequisites:**
> 1. Complete `product-research` skill first — you need the full Marketing Intelligence Layer (pain mining, awareness, angles, hooks, offer, creative direction)
> 2. Complete `product-image-safety` skill — you need the Product Identity Lock before generating any product-containing visuals

---

## When to use this skill

- When creating ad creatives for Meta (Facebook / Instagram), TikTok, or paid social
- When planning visual assets for a high-converting landing page
- When translating marketing angles into specific image concepts
- When generating photorealistic product-in-use visuals
- When you need a complete creative brief a designer or media buyer can execute from

## How to use it

### Step 1 — Angle Prioritization

Take the marketing angles from `product-research` (Step 8) and **rank them** before creating any visuals. Not all angles deserve images — pick the sharpest ones.

**Ranking criteria** (score 1–5 each):

| Criterion | What to evaluate |
|---|---|
| **Emotional strength** | Does it trigger a visceral reaction (fear, relief, desire)? |
| **Urgency** | Does it create a "I need this NOW" feeling? |
| **Clarity** | Can someone understand it in under 2 seconds? |

**Select the TOP 2 angles** for visual execution. The others remain as text-only ad copy angles.

Then **classify each planned image** by destination:

| Classification | Use for | Visual style |
|---|---|---|
| **Ad Creative** | Scroll stopper, cold traffic | Aggressive, high-tension, UGC feel |
| **Landing Image** | On-page trust & persuasion | Clean, controlled, studio feel |
| **Both** | Works in ads AND on landing page | Balanced — real but polished |

**Define the visual style** for this product:

- **UGC** — Raw, real, phone-camera feel. Messy backgrounds. Natural light. Imperfect framing. Best for: low-ticket, impulse buys, relatable products.
- **Studio** — Clean, controlled, premium. Dramatic lighting. Isolated product. Best for: high-ticket, aspirational, tech products.
- **Hybrid** — Studio product quality with lifestyle context. Best for: mid-market products that need both trust and relatability.

Output:

```markdown
### Angle Prioritization

| Angle | Emotional Strength | Urgency | Clarity | Total | Selected |
|---|---|---|---|---|---|
| Pain Angle | X/5 | X/5 | X/5 | X/15 | ✅/❌ |
| Result Angle | X/5 | X/5 | X/5 | X/15 | ✅/❌ |
| Social Proof Angle | X/5 | X/5 | X/5 | X/15 | ✅/❌ |
| Offer Angle | X/5 | X/5 | X/5 | X/15 | ✅/❌ |

**Selected angles for visuals:** [Angle 1], [Angle 2]
**Visual style:** [UGC / Studio / Hybrid]
```

---

### Step 2 — Image Strategy Brief

For **each** planned visual, define a strategy brief BEFORE generating anything. No image gets generated without a brief.

Output per image:

```markdown
### Image [N] — Strategy Brief

- **Goal:** [CTR / Trust / Desire / Urgency — what is this image's JOB?]
- **Angle used:** [Which of the top 2 selected angles]
- **Emotion:** [The ONE feeling this image must trigger — stress / relief / confidence / urgency / fear / excitement]
- **Big Idea:** [What makes THIS image different from generic product photos — the concept]
- **Core Message:** [What someone understands in 1 second flat — no reading required]
- **Classification:** [Ad Creative / Landing Image / Both]
```

---

### Step 3 — High-Conversion Image Types

Generate exactly **4 image types**. Each serves a different conversion role. Skip none.

#### Type 1 — SCROLL STOPPER
- **Purpose:** Stop the thumb. Get the click.
- **Requirements:**
  - Dramatic situation or unexpected scenario
  - Visible tension, urgency, or curiosity
  - Product may or may not be visible (depends on angle)
  - Must feel like a captured moment, not a posed shot
- **Prompt direction:** High contrast, dynamic composition, action frozen mid-moment

#### Type 2 — PROBLEM vs SOLUTION (Split Visual)
- **Purpose:** Instant before/after comprehension
- **Requirements:**
  - Left side: the PAIN (frustrating, dark, stressful)
  - Right side: the SOLUTION (relieved, bright, confident)
  - Product visible on solution side only
  - Clear visual contrast — lighting, color temperature, expression
- **Prompt direction:** Split composition, contrasting moods, same person/context both sides

#### Type 3 — REAL USE CASE (Action Shot)
- **Purpose:** Show the product solving the problem in real life
- **Requirements:**
  - Product actively being USED (not held, not displayed — USED)
  - Natural environment matching the use case
  - Person interacting with product naturally
  - Clear benefit visible in the scene
- **Prompt direction:** Candid feel, mid-action, environmental context

#### Type 4 — RESULT IMAGE
- **Purpose:** Show the emotional payoff AFTER using the product
- **Requirements:**
  - Focus on the OUTCOME, not the product itself
  - Person displaying relief, satisfaction, confidence
  - Product may be de-emphasized or in background
  - Aspirational but believable
- **Prompt direction:** Warm lighting, relaxed posture, genuine expression

Output:

```markdown
### Image Generation Plan

| # | Type | Angle | Emotion | Classification | Style |
|---|---|---|---|---|---|
| 1 | Scroll Stopper | [angle] | [emotion] | Ad Creative | [UGC/Studio] |
| 2 | Problem vs Solution | [angle] | [emotion] | Both | [UGC/Studio] |
| 3 | Real Use Case | [angle] | [emotion] | Landing Image | [UGC/Studio] |
| 4 | Result Image | [angle] | [emotion] | Landing Image | [UGC/Studio] |
```

---

### Step 4 — Photorealistic Product Integration

When generating any image that **contains the product**, these physics-level rules are MANDATORY. You are simulating reality, not placing a product onto a background.

> **Prerequisite:** The Product Identity Lock from `product-image-safety` must be included in every product-containing prompt.

> **⚠️ GENERATION STRATEGY — Compositing First:**
> Before generating a product-in-scene image, ask: "Can I achieve this by compositing the original product image into a generated scene?" If yes → generate the scene WITHOUT the product, then integrate the original image via CSS (`drop-shadow`, `mix-blend-mode`, `transform`). Only use full AI generation when the shot requires natural hand interaction or an angle not available in the original. See `product-image-safety` Step 4 for the full priority order.

#### Rule 1 — Real Hand Interaction
- Fingers wrap around the product naturally with proper grip pressure
- Thumb and finger positioning matches the product's actual shape and size
- Skin contact points show slight compression where touching the product
- **NEVER:** Floating product, fingers phasing through product, robotic grip

#### Rule 2 — Action-Based Posing
- The person is DOING something with the product: pressing, inflating, connecting, adjusting, applying, pouring, fastening
- Body posture reflects the physical action (leaning, reaching, gripping)
- **NEVER:** Static posing, product held up to camera like a display, "look what I have" poses

#### Rule 3 — Light Matching
- Light direction on the product matches the scene's light source
- Color temperature is consistent (warm scene = warm product highlights)
- Specular reflections on the product match the environment
- Cast light from the product's own features (LEDs, screens) affects nearby surfaces

#### Rule 4 — Shadow Physics
- **Contact shadows:** Dark, tight shadow directly where product touches surfaces/hands
- **Ambient shadows:** Softer, larger shadow matching the scene's ambient light
- **Cast shadows:** Product casts a directional shadow matching the key light
- **NEVER:** No shadow (floating effect), shadow going in wrong direction

#### Rule 5 — Depth of Field
- Product has the same focus/blur as objects at the same distance from camera
- If person is in focus, product in their hand is also in focus
- Background blur matches the lens/scene consistently

#### Rule 6 — Imperfection Layer
- Slight dust, fingerprints, or micro-scratches where appropriate
- Minor environmental imperfections (not a sterile studio unless that's the style)
- Real-world context clutter in background (but not distracting)
- **NEVER:** Hyper-clean, CGI-perfect, uncanny-valley smooth

**Include in every product-containing prompt:**
```
"[PRODUCT IDENTITY LOCK]. Photorealistic integration: natural hand grip with
visible finger pressure, action-based pose (not static), lighting and shadow
direction matching the scene, contact shadows where product touches surfaces,
consistent depth of field, subtle real-world imperfections. Must look like a
real photograph, not a product placement."
```

---

### Step 5 — Hook Visual Strategy

For **each image**, define what happens in the first 3 seconds (for video) or the first glance (for static). This is what stops the scroll.

Output per image:

```markdown
### Image [N] — Hook Visual

- **First 3 seconds:** [Exactly what the viewer sees — be specific: "A hand reaching into a dark trunk, pulling out a glowing device" not "someone using product"]
- **Why it stops scrolling:** [The psychological trigger — curiosity gap, pattern interrupt, recognition of own pain, unexpected visual]
- **Text overlay (if any):** [Short text that reinforces the hook — max 6 words]
```

---

### Step 6 — Creative Variations

For each of the 4 key visuals, create **two variations** to test:

| Variation | Style | Use when |
|---|---|---|
| **Variation A — Clean / Safe** | Polished, trustworthy, informative | Landing pages, retargeting, warm audiences |
| **Variation B — Emotional / Aggressive** | Raw, urgent, high-tension, confrontational | Cold traffic ads, scroll stoppers, TikTok |

Output per image:

```markdown
### Image [N] — Variations

**Variation A (Clean):**
- Tone: [calm / professional / aspirational]
- Lighting: [bright, even, studio-quality]
- Text overlay: [subtle, informative]
- Prompt adjustment: [what to change from base prompt]

**Variation B (Aggressive):**
- Tone: [urgent / confrontational / raw]
- Lighting: [dramatic, high-contrast, moody]
- Text overlay: [bold, provocative]
- Prompt adjustment: [what to change from base prompt]
```

---

### Step 7 — Creative Optimization Loop

After generating visuals, **evaluate each image** against these 3 checkpoints before accepting:

| Checkpoint | Question | Pass if... |
|---|---|---|
| **Scroll Stop** | Does it stop scrolling in a feed of 100 posts? | It creates visual friction — your eye can't skip it |
| **1-Second Clarity** | Can someone understand the message without reading? | The scenario, emotion, or contrast is instantly obvious |
| **Emotional Trigger** | Does it make someone FEEL something? | It triggers fear, desire, relief, curiosity, or urgency — not neutrality |

**If any image scores "no" on 2+ checkpoints → improve it:**

| Weakness | Fix |
|---|---|
| Doesn't stop scrolling | Add more visual tension, increase contrast, add unexpected element |
| Message unclear | Simplify the scene, remove clutter, make the action more obvious |
| No emotion | Change facial expression, add environmental stress/relief cues, use color psychology |
| Looks generic | Add specific context (time of day, weather, location details), imperfection layer |
| Looks like stock | Reduce symmetry, add natural hand positioning, increase environmental realism |

Output:

```markdown
### Creative Optimization Scorecard

| Image | Scroll Stop | 1s Clarity | Emotion | Status |
|---|---|---|---|---|
| 1 — Scroll Stopper | ✅/❌ | ✅/❌ | ✅/❌ | PASS / IMPROVE |
| 2 — Problem vs Solution | ✅/❌ | ✅/❌ | ✅/❌ | PASS / IMPROVE |
| 3 — Real Use Case | ✅/❌ | ✅/❌ | ✅/❌ | PASS / IMPROVE |
| 4 — Result Image | ✅/❌ | ✅/❌ | ✅/❌ | PASS / IMPROVE |

**Improvements applied:** [List what was changed on any IMPROVE images]
```

---

### Step 8 — Final Validation Gate

Before delivering ANY image, it must pass this gate. No exceptions.

**REJECT if:**
- ❌ Product looks pasted onto the scene (edge artifacts, wrong perspective)
- ❌ Lighting on product doesn't match scene lighting
- ❌ No visible emotion in the scene (neutral face, empty context)
- ❌ No clear message — viewer wouldn't know what's being sold or why
- ❌ Product identity differs from the Identity Lock (wrong shape, color, branding)
- ❌ Hands look unnatural (wrong finger count, impossible grip, floating contact)
- ❌ Looks like stock photography (too perfect, too generic, too clean)

**ACCEPT only if:**
- ✅ Looks like a real photograph taken by a real person or photographer
- ✅ Shows clear, specific ACTION (not posing, not displaying)
- ✅ Communicates the message INSTANTLY without needing text
- ✅ Product matches the Identity Lock exactly
- ✅ Passes all 3 checkpoints from the Optimization Loop

**If rejected → regenerate with adjusted prompt. Do NOT ship rejected images.**

---

## Examples

### Example 1 — Tech Product (Portable Tire Inflator)

**Prerequisites completed:**
- Product Profile from `product-research` ✓
- Identity Lock from `product-image-safety` ✓
- Marketing Intelligence (pains, angles, hooks, offer) ✓

**Angle Prioritization:**

| Angle | Emotional | Urgency | Clarity | Total | Selected |
|---|---|---|---|---|---|
| Pain (stranded) | 5 | 5 | 4 | 14 | ✅ |
| Result (4-min fix) | 4 | 4 | 5 | 13 | ✅ |
| Social Proof | 3 | 2 | 3 | 8 | ❌ |
| Offer (bundle) | 2 | 3 | 4 | 9 | ❌ |

Style: **Hybrid** (real-world context + clear product detail)

**Image Plan:**

| # | Type | Angle | Emotion | For |
|---|---|---|---|---|
| 1 | Scroll Stopper | Pain | Fear/urgency | Ad Creative |
| 2 | Problem vs Solution | Pain → Result | Stress → Relief | Both |
| 3 | Real Use Case | Result | Confidence | Landing Image |
| 4 | Result Image | Result | Relief/pride | Landing Image |

**Scroll Stopper hook:** Dark highway shoulder, car hazard lights flashing, a hand pulling the compact inflator from the trunk — LED light cutting through darkness. First 3 sec = pure tension before the solution appears.

**Validation:** Product must show exact Identity Lock details (LCD display, AIRMOTO branding, coiled hose, red power button). Natural hand grip around rubberized body. Contact shadow on trunk surface.

### Example 2 — Fashion Product (Gold Crystal Bracelet)

**Angle Prioritization:**

| Angle | Emotional | Urgency | Clarity | Total | Selected |
|---|---|---|---|---|---|
| Pain (invisible) | 4 | 2 | 4 | 10 | ❌ |
| Result (compliments) | 5 | 3 | 5 | 13 | ✅ |
| Identity ("for women who...") | 5 | 3 | 4 | 12 | ✅ |
| Offer (buy 2 get 1) | 2 | 4 | 5 | 11 | ❌ |

Style: **Studio** with lifestyle accents

**Scroll Stopper hook:** Close-up of a wrist resting on a café table, gold bracelet catching natural window light, coffee cup and phone blurred in background — the viewer's eye goes straight to the sparkle. Text overlay: "She asked where I got it."

---

## Constraints

- **Do NOT** generate any image without completing the Image Strategy Brief (Step 2) first
- **Do NOT** generate product-containing images without the Identity Lock from `product-image-safety`
- **Do NOT** create more than 2 angles for visuals — focus beats volume
- **Do NOT** skip the Photorealistic Integration rules for any product-containing image
- **Do NOT** accept images that fail the Final Validation Gate — regenerate instead
- **Do NOT** create "safe" images only — every set needs at least one aggressive Variation B
- **ALWAYS** complete Angle Prioritization before planning any images
- **ALWAYS** run the Creative Optimization Loop after generation, before delivery
- **ALWAYS** define the hook visual (first 3 seconds / first glance) for every image
- **ALWAYS** classify each image as Ad Creative / Landing Image / Both
- **ALWAYS** reference the marketing intelligence from `product-research` — never create visuals in a strategy vacuum
- If an image looks like stock photography → REJECT and regenerate
- If an image doesn't trigger emotion → REJECT and regenerate
