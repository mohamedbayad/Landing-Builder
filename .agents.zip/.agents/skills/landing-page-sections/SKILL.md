---
name: landing-page-sections
description: Provides HTML/CSS patterns for every landing page section including hero, features, testimonials, and conditional slots.
---

# Landing Page Section Library

Complete HTML/CSS patterns for every section of a high-converting landing page. Each section has one purpose — don't mix concerns.

> **Prerequisite:** Use `landing-page-design` for theming/typography. This skill covers section structure and layout only.

---

## When to use this skill

- When building the HTML/CSS for a specific landing page section
- When deciding which sections to include based on product category
- When choosing the right conditional section (Slot 6) for a product type
- When deciding whether to include the comparison section (Slot 5.5)

## How to use it

### Page Architecture — Adaptive Commercial Flow

Single-column, narrative-driven scroll. No sidebars. No multi-column confusion.

**Fixed Sections (all products):**
```
1. HERO — Full-impact visual + one headline
2. PROOF BAR — Logos / Stats / Press
3. PROBLEM — Elegant pain agitation
4. SOLUTION — The product reveal
5. FEATURES — Clean icon grid
5.5 ★ COMPARISON (optional) — Old Way vs New Way
6. ★ CONDITIONAL (adapts to product)
7. SOCIAL PROOF — Testimonials
8. GUARANTEE — Risk reversal
9. OFFER — Pricing + CTA
10. FAQ — Kill final objections
11. FOOTER CTA — Last chance
```

### Classify Product First

| Category | Slot 6 Section | Supports Comparison? |
|---|---|---|
| **Transformation** (skincare, fitness, cleaning) | Before & After | ✅ Yes |
| **Fashion / Lifestyle** (shoes, bags, jewelry) | Lifestyle Showcase | ❌ No |
| **Artisan / Handmade** (leather, pottery, craft) | Craftsmanship | ⚠️ Maybe |
| **Tech / Gadgets** (devices, tools, electronics) | Use Cases | ✅ Yes |
| **Home / Decor** (candles, lamps, rugs) | Lifestyle Showcase | ❌ No |
| **Beauty** (with visible results) | Before & After | ⚠️ Maybe |
| **Beauty** (no visible result) | Lifestyle Showcase | ❌ No |

### Slot 5.5 — Comparison Decision

**Include if:** Product replaces a manual/inferior method, saves time/effort/money.  
**Skip if:** Product is aesthetic (fashion, jewelry, decor) or has no "old way."

### Section Patterns

**Hero** — See `references/section-css-library.md` for full CSS. Key patterns:
- Centered text above full-width product photo (physical product)
- Split layout: text left, device mockup right (digital/SaaS)
- Full-bleed product image with overlaid text (fashion)

**Proof Bar** — Logos or key statistics with subtle borders above and below.

**Problem** — Empathetic editorial tone. 3 pain points max. No aggressive "ARE YOU TIRED OF" headlines.

**Solution** — 2-column grid (text + product image). Product is the star.

**Features** — 3-column icon grid. 4-6 features max. Feature → Benefit translation mandatory.

**Testimonials** — 3-column card grid. Story-driven quotes with scenario + benefit + emotion. Real names + Verified Buyer badge.

**Guarantee** — Centered card with icon badges (free shipping, 30-day returns, secure checkout).

**Offer** — Price display with original/current price, value stack, urgency messaging, final CTA.

**FAQ** — Accordion with toggle. 4-6 questions addressing real objections.

### Conditional Sections (Slot 6)

**Before & After** — Side-by-side cards. "Before" desaturated with grayscale filter. "After" bright and positive.

**Lifestyle Showcase** — 3-image masonry grid. First image spans 2 rows. Product in aspirational environments.

**Craftsmanship** — 3-column icon grid highlighting materials, handcrafted process, and durability. Large detail image below.

**Use Cases** — 3 scenario cards, each with image + title + one-line description. Tailored to product category.

### Layout Rules

- NO navigation menu — the only exit is the CTA
- NO external links — every click leads to conversion
- Max-width: `1140px` for content, `100%` for full-bleed
- Padding: `100px 0` between sections (desktop), `64px 0` (mobile)
- Each section has ONE purpose — don't mix

---

## Examples

### Example 1 — Tech Product Section Plan

**Input:** Portable tire inflator  
**Output:**
```
1. Hero (centered, product below)
2. Stat Bar (12K+ customers, 4.9★, 98% satisfaction)
3. Problem (flat tire scenarios, empathetic tone)
4. Solution (split layout, inflator + benefit text)
5. Features (6 cards: 120 PSI, LED light, auto-shutoff, USB-C, portable, universal)
5.5. Comparison (gas station pump vs Airmoto pocket inflator)
6. Use Cases (car, bike, sports equipment)
7. Testimonials (3 story-driven reviews)
8. Guarantee card
9. Offer (price + value stack)
10. FAQ (5 questions)
11. Footer CTA
```

### Example 2 — Fashion Product Section Plan

**Input:** Moroccan babouche slippers  
**Output:**
```
1. Hero (full-bleed product, warm theme)
2. Proof Bar ("Handcrafted in Fez", "Premium Leather", "Free Shipping")
3. Craftsmanship (materials, handmade process, durability)
4. Solution (product reveal with heritage story)
5. Features (4 cards: soft leather, flat sole, hand-stitched, no-heel)
6. Lifestyle Showcase (terrace, flat lay, entryway — 3 images)
7. Testimonials
8. Guarantee
9. Offer
10. FAQ (sizing, care, shipping)
11. Footer CTA
```

---

## Constraints

- **Do NOT** include a navigation menu — CTA is the only exit
- **Do NOT** add external links — everything leads to conversion
- **Do NOT** force a comparison section for fashion/decor/aesthetic products
- **Do NOT** mix section purposes — each section does one thing
- **Do NOT** use more than 6 feature cards
- **Do NOT** write generic testimonials — every quote needs scenario + benefit
- **ALWAYS** classify the product BEFORE choosing sections
- **ALWAYS** include micro-trust below every CTA
