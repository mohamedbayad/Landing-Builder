---
name: product-research
description: Researches a product from its image to extract type, niche, audience, competitive positioning, and builds a complete marketing intelligence profile (pain mining, awareness levels, angles, offer engineering, ad hooks, creative direction).
---

# Product Research from Image

When a user provides a product image, follow this workflow to gather comprehensive product intelligence **before** designing anything.

---

## When to use this skill

- When a product image is provided without detailed product context
- Before creating any landing page copy, design, or structure
- When you need to understand the target audience, pain points, and competitive landscape
- When determining the right marketing angle for a product

## How to use it

### Step 1 — Visual Analysis

Study the product image and extract:
1. **Product category** — electronics, fashion, beauty, fitness, home, automotive, etc.
2. **Physical characteristics** — size, shape, color, material, components
3. **Branding clues** — logos, text, model numbers visible
4. **Quality tier** — budget, mid-range, or premium (based on packaging, finish, materials)
5. **Use context** — where/how someone would use this

### Step 2 — Web Research

Use `search_web` with a descriptive query based on your visual analysis:

```
Query format: "[product description] [any visible brand/text] [product category] buy"
```

If the first search doesn't find exact matches, try:
- Add visible text/brand names
- Search in the product's likely language market
- Try "[brand name] [product type] official"

### Step 3 — Compile Product Profile

```markdown
## Product Profile

**Product Name:** [Exact name if found, or descriptive name]
**Brand:** [Brand name or "Unbranded/White-label"]
**Category:** [Main category]
**Niche:** [Specific sub-niche]
**Price Range:** [$X-$Y]

### Key Features
1. [Feature + benefit]
2. [Feature + benefit]
3. [Feature + benefit]

### Target Audience
- **Demographics:** [Age, gender, income level]
- **Psychographics:** [Lifestyle, values, pain points]
- **Use case:** [Primary situation where they'd buy this]

### Competitive Landscape
- **Direct competitors:** [2-3 competing products]
- **Unique advantage:** [What makes this one stand out]

### Landing Page Recommendations
- **Theme suggestion:** [dark / light / warm — based on product]
- **Hero style:** [Which hero variant to use]
- **Key selling angle:** [The #1 message to lead with]
- **Trust signals:** [What social proof matters most]
```

### Step 4 — Color Extraction

From the product image, extract:
1. **Dominant color** → Use as `--accent` for CTAs
2. **Secondary color** → Tags, badges, icons
3. **Neutral tone** → Alternate section backgrounds

**Rules:** Warm products → warm accent + dark bg. Cool products → cool accent. Black/neutral → pick ONE vibrant accent to contrast.

---

## Marketing Intelligence Layer

> Complete all sections below **after** compiling the Product Profile. These steps transform a basic product analysis into an actionable marketing strategy that a media buyer, copywriter, or designer can execute from directly.

### Step 5 — Deep Pain Mining

Dig beneath surface-level problems. Identify the **emotional** pain, not just the functional inconvenience.

Output:

```markdown
### Deep Pain Analysis

- **Pain 1:** [Specific emotional pain — what keeps them up at night]
- **Pain 2:** [Specific emotional pain — what makes them feel frustrated/inadequate]
- **Pain 3:** [Specific emotional pain — what they're secretly embarrassed about]

- **Hidden frustrations:** [What they've tried before that failed them]
- **What they're tired of:** [The recurring annoyance they've accepted as "normal"]

- **Emotional triggers:**
  - **Fear:** [What bad outcome are they trying to avoid?]
  - **Desire:** [What future state are they dreaming about?]
  - **Frustration:** [What specific moment makes them snap and decide to buy?]
```

### Step 6 — Market Awareness Level

Classify the target audience using **Eugene Schwartz's 5 Awareness Levels**:

| Level | Description |
|---|---|
| **Unaware** | Doesn't know they have a problem |
| **Problem Aware** | Knows the pain but not the solution |
| **Solution Aware** | Knows solutions exist, hasn't picked one |
| **Product Aware** | Knows this product, hasn't bought yet |
| **Most Aware** | Ready to buy, needs the right deal |

Output:

```markdown
### Market Awareness Level

- **Level:** [Problem Aware / Solution Aware / etc.]
- **What they already know:** [Their existing knowledge and beliefs]
- **What they need to be convinced of:** [The gap between current state and purchase]
- **Messaging implication:** [How to open — educate vs. agitate vs. present offer]
```

### Step 7 — Market Sophistication

Determine where the market sits in its lifecycle:

- **Level 1 — New market:** Be first. Simple, direct claims work.
- **Level 2 — Growing:** Competitors exist. Make BIGGER claims with proof.
- **Level 3 — Mature:** Claims are everywhere. Use **unique mechanisms** ("how it works differently").
- **Level 4 — Saturated:** Nobody believes claims. Use **identification** (speak to who they ARE).
- **Level 5 — Dead/Cynical:** Only raw story, proof, or demonstration cuts through.

Output:

```markdown
### Market Sophistication

- **Level:** [1-5 + label]
- **What messaging works:** [Specific approach for this level]
- **What to AVOID:** [What will make the audience tune out immediately]
```

### Step 8 — Angles Strategy

Generate **at least 4** distinct marketing angles. Each must be specific to this product — no generic fillers.

Output:

```markdown
### Marketing Angles

1. **Pain Angle:** [Lead with the #1 frustration. Agitate it. Present product as relief.]
2. **Result Angle:** [Lead with the desired end state. Show transformation.]
3. **Social Proof Angle:** [Lead with what other people are saying/doing. Bandwagon + credibility.]
4. **Offer Angle:** [Lead with irresistible value — price, bonuses, guarantee, scarcity.]
5. **[Optional] Contrarian Angle:** [Challenge a common belief in the niche.]
```

### Step 9 — Offer Engineering

Design a compelling offer stack that makes saying "no" feel irrational.

Output:

```markdown
### Offer Structure

- **Core Offer:** [Product + primary value proposition in one sentence]
- **Bonuses:**
  1. [Bonus that removes a secondary objection — e.g. guide, accessory, extended warranty]
  2. [Bonus that increases perceived value — e.g. exclusive content, fast-action reward]
  3. [Optional — bonus that adds social proof or community access]
- **Guarantee:** [Risk-reversal type — 30-day money-back / lifetime / try-before-you-buy]
- **Urgency / Scarcity:** [Time-limited discount / limited stock / launch pricing / seasonal angle]
```

### Step 10 — Ad Hooks (Meta Ads)

Generate **5 high-converting hooks** for paid social (Facebook / Instagram / TikTok). Each hook must work as a standalone first line or first 3 seconds of video.

Output:

```markdown
### Ad Hooks

1. **Pattern Interrupt:** [Unexpected statement that stops the scroll]
2. **Curiosity-Driven:** [Open loop that creates an itch to learn more]
3. **Problem-Focused:** [Call out the pain so directly they feel seen]
4. **Bold Claim:** [Specific, provable result that demands attention]
5. **Story-Based:** ["I was [relatable situation]... then I found this."]
```

### Step 11 — Creative Direction

Define the visual and format strategy for ads and landing page assets.

Output:

```markdown
### Creative Direction

- **Visual style:** [UGC / studio / lifestyle / before-after / unboxing]
- **Best ad format:** [Video / carousel / static image — and WHY]
- **First 3 seconds concept:** [What the viewer sees/hears that hooks them visually]
- **Landing page hero visual:** [What image or video plays above the fold]
- **Color mood:** [Dark & premium / bright & energetic / warm & trustworthy — tie to product colors from Step 4]
```

---

## Examples

### Example 1 — Tech Gadget (Portable Air Pump)

**Input:** Image of a black portable air pump  
**Search query:** `"portable wireless air pump compressor car tire inflator buy"`

**Product Profile excerpt:**  
Category: Automotive / Tech · Dark theme · Problem→solution angle

**Marketing Intelligence excerpt:**

```
Deep Pain Analysis:
- Pain 1: Fear of being stranded on the road at night with no help
- Pain 2: Embarrassment of calling someone for a flat tire
- Frustration trigger: Wasting 45 min waiting for roadside assistance

Market Awareness: Problem Aware — they know flat tires are a risk, haven't considered a portable solution
Market Sophistication: Level 2 — Growing. Competitors exist. Lead with proof + bigger claims.

Angles:
1. Pain: "Still waiting 45 minutes for roadside assistance? There's a $39 fix."
2. Result: "Inflate any tire in under 4 minutes — from your trunk."
3. Social Proof: "200,000+ drivers keep this in their glovebox."
4. Offer: "Get the pump + carry case + tire repair kit — 40% off this week."

Ad Hook (Pattern Interrupt): "Your spare tire is probably flat too."

Creative Direction: UGC video — nighttime roadside scene, pump inflating tire with LED light on. First 3 sec: darkness, headlights, then the pump's LED clicks on.
```

### Example 2 — Fashion Accessory (Gold Bracelet)

**Input:** Image of a gold bracelet with stones  
**Search query:** `"gold crystal stone bracelet women luxury jewelry buy"`

**Product Profile excerpt:**  
Category: Fashion / Jewelry · Warm theme · Lifestyle/aspiration angle

**Marketing Intelligence excerpt:**

```
Deep Pain Analysis:
- Pain 1: Feeling invisible — wanting to look put-together without effort
- Pain 2: Buying cheap jewelry that tarnishes or turns green
- Desire trigger: Being complimented on their style unprompted

Market Awareness: Solution Aware — they buy jewelry regularly, looking for something elevated
Market Sophistication: Level 4 — Saturated. Lead with identity ("for women who...").

Ad Hook (Story-Based): "My coworker asked if this was designer. It was $24."

Offer: Bracelet + velvet pouch + free size exchange · 60-day satisfaction guarantee · "Launch week: buy 2 get 1 free"
```

### Example 3 — Dashboard Camera

**Input:** Image of a dual-lens dashcam  
**Search query:** `"dual lens dashcam front rear camera 4K car buy"`

**Product Profile excerpt:**  
Category: Automotive / Tech · Dark theme · Safety/protection angle

**Marketing Intelligence excerpt:**

```
Deep Pain Analysis:
- Pain 1: Fear of being blamed in an accident with no proof
- Pain 2: Insurance disputes where it's your word against theirs
- Frustration trigger: Paying higher premiums after a not-at-fault accident

Market Awareness: Solution Aware — they know dashcams exist, comparing features
Market Sophistication: Level 3 — Mature. Lead with unique mechanism ("dual 4K + night vision").

Ad Hook (Bold Claim): "This $59 camera saved a driver $14,000 in insurance claims."

Creative Direction: Split-screen before/after — blurry phone footage vs. crystal-clear 4K dashcam footage of the same scene. Static carousel + 15s video.
```

---

## Constraints

### Product Profile (Steps 1–4)
- **Do NOT** skip the web research step — always validate assumptions with real search data
- **Do NOT** proceed to design before presenting the Product Profile to the user for confirmation
- **Do NOT** assume product details not visible in the image — research first
- **ALWAYS** extract colors from the actual product image for theme decisions
- **ALWAYS** include competitive landscape — never design in a vacuum

### Marketing Intelligence Layer (Steps 5–11)
- **Do NOT** skip any Marketing Intelligence section — all 7 steps are mandatory
- **Do NOT** use generic or vague language — every pain, angle, hook, and offer element must be specific to THIS product and THIS audience
- **Do NOT** write filler hooks ("You won't believe this!") — every hook must reference a real pain, result, or story
- **Do NOT** copy the same angle in different formats — each angle must approach the sale from a genuinely different entry point
- **ALWAYS** complete all 11 steps before handing off the output for landing page, ad, or funnel creation
- **ALWAYS** tie creative direction back to the product colors and quality tier identified in Steps 1–4
- **ALWAYS** make the offer structure feel like a no-brainer — if the offer doesn't make saying "no" feel irrational, rework it
