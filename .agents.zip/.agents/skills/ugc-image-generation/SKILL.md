---
name: ugc-image-generation
description: Generates section-aware marketing images from a product photo while preserving exact product identity.
---

# UGC Image Generation

Generate **section-aware, conversion-focused images** for landing pages from any product image. Creates lifestyle shots, social media visuals, and in-use scenes while keeping the product accurate.

> **Prerequisite:** Complete `product-image-safety` skill first — the Product Identity Lock must exist before generating any images.

---

## When to use this skill

- When generating images for specific landing page sections (hero, solution, use cases, lifestyle, before/after)
- When creating lifestyle or in-use product photography from a single product photo
- When deciding which sections need AI-generated images vs original images vs no images

## How to use it

### Step 1 — Confirm Prerequisites

Before generating, verify:
- Product Identity Lock exists (from `product-image-safety`)
- Context Lock captured from user's product description
- Composition decisions made (elements, accessories, angle, purpose)

### Step 2 — Section-Specific Generation

Use the appropriate template for each section:

**HERO — Premium Product Shot** (prefer original image):
```
Prompt: "[FULL IDENTITY LOCK]. This exact product photographed in a
         professional studio against a dark background, dramatic side
         lighting. All components from reference visible and unaltered.
         [STRICT PRESERVATION INSTRUCTION]"
ImagePaths: ["/path/to/original-product.png"]
ImageName: "hero_product"
```

**PROBLEM — Pain Scene** (no product):
```
Prompt: "[Problem scenario]. Person looking frustrated/struggling.
         Relevant environment. Dim lighting. No products visible."
ImageName: "problem_scene"
```
*No `ImagePaths` — product must NOT appear.*

**USE CASES — Real Scenarios** (3 images):
```
Prompt: "[FULL IDENTITY LOCK]. Person using this exact product for
         [specific use case]. [Environment]. Natural lighting. Product
         clearly visible and in active use. [STRICT PRESERVATION INSTRUCTION]"
ImagePaths: [original]
ImageName: "usecase_[N]"
```

**LIFESTYLE SHOWCASE — Aspirational Settings** (3 shots):
- Shot 1: Person wearing/holding/using the product naturally
- Shot 2: Product styled on a surface with complementary items
- Shot 3: Product in full environment telling a story

**BEFORE & AFTER — Transformation:**
- Before: Problem state, no product visible
- After: Improved outcome with product, bright natural lighting

### Step 3 — Sections That Need NO AI Generation

| Section | Use Instead |
|---|---|
| Proof Bar | Logos, stat numbers, rating badges |
| Features | SVG icons (Lucide/Feather) |
| Social Proof | Testimonial cards, text |
| Guarantee | Badge SVGs (shield, truck, lock) |
| FAQ | Text only |
| Offer | Reuse hero product image |

### Step 4 — Total Image Budget

4-6 images maximum per landing page. Each must serve a clear strategic purpose.

---

## Examples

### Example 1 — Tech Product (3 Use Case Images)

**Input:** Portable tire inflator + Identity Lock  
**Output:**
- `usecase_1`: Person using inflator on car tire at roadside (emergency scenario)
- `usecase_2`: Person inflating bicycle tire in garage (daily use)
- `usecase_3`: Person inflating sports ball in backyard (versatility)

### Example 2 — Fashion Product (3 Lifestyle Shots)

**Input:** Emerald green babouche + Identity Lock  
**Output:**
- `lifestyle_1`: Person wearing babouche stepping onto terrace (in-use)
- `lifestyle_2`: Babouche styled on marble surface with coffee cup (flat lay)
- `lifestyle_3`: Babouche by entryway of warm Moroccan-style home (environment)

---

## Constraints

- **Do NOT** generate images without completing `product-image-safety` first
- **Do NOT** include the product in Problem section images
- **Do NOT** exceed 6 images per landing page
- **Do NOT** use generic category terms in prompts — always use the full Identity Lock
- **Do NOT** generate images for sections that work better with icons or text
- **ALWAYS** include `ImagePaths` with the original product image for any product-containing generation
- **ALWAYS** include the Strict Preservation Instruction in every product-containing prompt
- If a hero generation alters ANY product detail → discard and use original image with CSS
