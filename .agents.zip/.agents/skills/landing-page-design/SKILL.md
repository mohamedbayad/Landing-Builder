---
name: landing-page-design
description: Defines the visual design system for high-converting landing pages including theming, typography, and responsive rules.
---

# Landing Page Design System

Defines **exactly how** to style a landing page that converts. Every rule is derived from analyzing high-performing commercial pages. The aesthetic is **clean, editorial, and premium** — never generic or template-looking.

> Think Apple, Dyson, Glossier, Aesop — not a cheap ClickFunnels template.

---

## When to use this skill

- When applying visual styling to a landing page (colors, fonts, spacing, animations)
- When choosing a theme (dark, light, warm) for a product category
- When implementing the CSS variable / `data-theme` theming system
- When defining typography tokens, CTA button styles, or responsive breakpoints
- When adding visual polish (noise overlay, dividers, subtle animations)

## How to use it

### Design Philosophy — Clean Commercial

1. **Restraint over excess.** Fewer elements, more white space, bigger impact.
2. **Typography is the hero.** Clean layout makes words hit harder.
3. **Product is king.** Every pixel exists to make the product irresistible.
4. **Invisible structure.** The page should flow naturally, not feel "designed."
5. **No visual noise.** No glitter, loud gradients, or cluttered badges.

### Color System & Theming

Every landing page uses **ONE consistent theme**. All backgrounds, text, borders, and surfaces come from the **same palette**.

**Step 1 — Choose the Theme:**

| Theme | Best For | Background | Text |
|---|---|---|---|
| **Dark** | Tech, gadgets, automotive, premium | `#0C0C0E` – `#1C1C1F` | `#F5F5F7` – `#6E6E73` |
| **Light** | E-commerce, lifestyle, beauty, home | `#FFFFFF` – `#F0F0F2` | `#1D1D1F` – `#A1A1A6` |
| **Warm** | Fashion, beauty, food, artisan | `#FAF7F2` – `#FFFFFF` | `#1A1A1A` – `#5A5A5A` |

**Step 2 — Apply `data-theme` to root:** `<html data-theme="dark">`

**Step 3 — CSS Variables (all three themes):**

```css
[data-theme="dark"] {
  --bg-primary: #0C0C0E;
  --bg-elevated: #161618;
  --bg-subtle: #1C1C1F;
  --text-primary: #F5F5F7;
  --text-secondary: #A1A1A6;
  --text-tertiary: #6E6E73;
  --accent: #2997FF;
  --accent-dark: #0071E3;
  --border: rgba(255, 255, 255, 0.08);
  --border-hover: rgba(255, 255, 255, 0.2);
  --card-bg: rgba(22, 22, 24, 0.6);
  --cta-text: #FFFFFF;
}

[data-theme="light"] {
  --bg-primary: #FFFFFF;
  --bg-elevated: #F8F8FA;
  --bg-subtle: #F0F0F2;
  --text-primary: #1D1D1F;
  --text-secondary: #6E6E73;
  --text-tertiary: #A1A1A6;
  --accent: #0071E3;
  --accent-dark: #004EAA;
  --border: rgba(0, 0, 0, 0.06);
  --border-hover: rgba(0, 0, 0, 0.15);
  --card-bg: rgba(255, 255, 255, 0.7);
  --cta-text: #FFFFFF;
}

[data-theme="warm"] {
  --bg-primary: #FAF7F2;
  --bg-elevated: #FFFFFF;
  --bg-subtle: #F5F0E8;
  --text-primary: #1A1A1A;
  --text-secondary: #5A5A5A;
  --text-tertiary: #8A8A8A;
  --accent: #C8965A;
  --accent-dark: #1A1A1A;
  --border: rgba(0, 0, 0, 0.08);
  --border-hover: rgba(0, 0, 0, 0.15);
  --card-bg: rgba(255, 255, 255, 0.8);
  --cta-text: #FFFFFF;
}
```

Override `--accent` per product (e.g., `--accent: #FF3B30` for automotive).

**Step 4 — Always include the theme toggle** (button + CSS + JS).

### Typography

```css
--font-heading: 'DM Sans', 'Inter', sans-serif;
--font-body: 'Inter', 'DM Sans', sans-serif;
--font-accent: 'Playfair Display', 'DM Serif Display', serif;
```

| Element | Desktop | Mobile | Weight |
|---|---|---|---|
| Hero Headline | `3rem – 4.5rem` | `2rem – 2.8rem` | 700–800 |
| Section Title | `2rem – 2.5rem` | `1.5rem – 1.8rem` | 600–700 |
| Eyebrow / Tag | `0.75rem` | `0.7rem` | 600, UPPERCASE |
| Body Text | `1.05rem – 1.15rem` | `0.95rem` | 400 |
| CTA Text | `0.9rem – 1rem` | `0.85rem` | 600, UPPERCASE |

### CTA Button Design

```css
.cta-primary {
  font-weight: 600; font-size: 0.95rem;
  text-transform: uppercase; letter-spacing: 1.5px;
  color: #fff; background: var(--accent);
  padding: 16px 40px; border-radius: 12px;
  transition: all 0.2s ease;
}
.cta-primary:hover { opacity: 0.88; transform: translateY(-2px); }
```

**CTA Rules:** Action verbs only ("Get Yours", not "Submit"). Appears 3 times: hero, mid-page, final. Micro-trust below every CTA. ONE primary style — no competing colors.

### Responsive Design

```css
@media (max-width: 768px) {
  section { padding: 64px 20px; }
  h2 { font-size: 1.6rem; }
  .cta-primary { width: 100%; justify-content: center; }
}
```

**Mobile rules:** Full-width CTAs below 768px. Stack all grids to single column. Font sizes scale down 25-30%. Touch targets ≥ 48px. Product image above text.

### Visual Polish

- Noise overlay at `opacity: 0.03` for premium texture
- Border-radius: `16px` cards, `12px` buttons, `8px` small elements
- SVG icons only (Lucide/Feather), consistent `stroke-width: 1.5`
- No glow effects, neon borders, or heavy drop-shadows
- No background gradients — flat, solid `var(--bg-*)` only

### Category-Specific Quality

| Category | Page Feel | Theme |
|---|---|---|
| **Tech / Gadgets** | Premium, precise, dark | Dark |
| **Artisan / Handmade** | Refined, authentic, editorial | Warm |
| **Fashion / Lifestyle** | Elegant, aspirational | Warm or Light |
| **Beauty** | Luxurious, sensorial | Light or Warm |
| **Home / Decor** | Warm, styled, atmospheric | Light or Warm |

---

## Examples

### Example 1 — Dark Theme (Tech Product)

**Input:** Portable tire inflator (black, tech product)  
**Output:** `data-theme="dark"`, accent `#2997FF`, DM Sans headings, dark background, blue CTAs, noise overlay.

### Example 2 — Warm Theme (Artisan Product)

**Input:** Moroccan babouche (emerald green leather)  
**Output:** `data-theme="warm"`, accent `#C8965A`, Playfair Display serif accents, cream background, gold CTAs.

---

## Constraints

- **Do NOT** hardcode hex colors — use `var(--token)` only
- **Do NOT** use more than 3 color roles: background + text + ONE accent
- **Do NOT** mix tokens from different themes — one palette per page
- **Do NOT** make headlines ALL CAPS — use sentence case (exception: eyebrows + CTAs)
- **Do NOT** use background gradients — flat solid colors only
- **Do NOT** use emoji for icons — SVG only (Lucide/Feather)
- **ALWAYS** include the theme toggle (button + CSS + JS) on every page
- **ALWAYS** include `dark:` Tailwind counterparts when using Tailwind
