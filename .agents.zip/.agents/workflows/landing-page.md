---
description: Generate a complete, high-converting landing page from a product image and short description
---

# Landing Page Generation — Master Workflow

Orchestrates **18 skills** across **11 phases** to produce a conversion-ready landing page with realistic visuals, SEO optimization, and builder compatibility.

**Inputs:** (1) product image, (2) short description, (3) optional context.

---

## System Architecture

```
PHASE 1-2    → THINK      (Understand the product)
PHASE 3-4    → STRATEGIZE  (Define how to sell it)
PHASE 5-6    → DESIGN      (Plan how it looks)
PHASE 7      → VISUALIZE   (Generate images)
PHASE 8-9    → BUILD       (Generate code)
PHASE 10-11  → VALIDATE    (Quality + security gate)
```

### Skill Classification

| Role | Skills | Purpose |
|---|---|---|
| **THINKING** | `product-image-safety`, `product-research`, `seo-keyword-strategist` | Input analysis, research, identity extraction |
| **STRATEGY** | `ad-creative-strategy`, `conversion-copywriting`, `seo-structure-architect`, `seo-meta-optimizer` | Angles, hooks, copy, SEO structure |
| **DESIGN** | `landing-page-design`, `landing-page-structure`, `landing-page-sections` | Theme, layout, section architecture |
| **GENERATION** | `ugc-image-generation` | Photorealistic product visuals |
| **INTEGRATION** | `landing-builder-compat`, `frontend-tailwind-system` | Builder output, styling system |
| **VALIDATION** | `frontend-security`, `seo-content-optimizer`, `seo-authority-builder`, `seo-audit` | Quality gates, security, E-E-A-T |
| **ON-CALL** | `seo-incident-response` | Post-launch traffic drop diagnostics |

### Data Flow

```
Product Image ─→ Identity Lock ─→ Image Prompts ─→ Generated Visuals
                        │                                    │
Product Image ─→ Product Profile ─→ Marketing Intelligence ──┤
                        │                │                    │
                   SEO Keywords ─→ SEO Structure ──────→ Final HTML
                                         │                    │
                   Copy Strategy ────────┘                    │
                                                              │
                   Design System ─→ Section Plan ─→ HTML/CSS ─┘
                                                       │
                   Builder Compat ─────────────────────┘
```

---

## PHASE 1 — INPUT & PRODUCT SAFETY

> **Role:** THINKING — Extract product identity before anything else.

**Skills:** `product-image-safety`

// turbo
1. Study the uploaded product image → extract full visual inventory using the Universal Extraction Checklist (geometry, surface, primary face, secondary details, attachments, branding, composition)
2. Compile the **Product Identity Lock** — a detailed paragraph describing every visible product detail
3. Classify the product category: Tech / Fashion / Artisan / Beauty / Home / Transformation / Automotive / Tools

**Outputs passed forward:**
- ✅ Product Identity Lock (used in all image prompts)
- ✅ Product category classification (drives all design decisions)

**Gate:** Identity Lock must be complete before proceeding. If image is unclear, ask the user for clarification.

---

## PHASE 2 — RESEARCH & INTELLIGENCE

> **Role:** THINKING — Build the complete marketing intelligence profile.

**Skills:** `product-research`, `seo-keyword-strategist`

// turbo
4. **Visual Analysis** — Extract product features, quality tier, use context (`product-research` Steps 1-2)
// turbo
5. **Web Research** — Use `search_web` to find: competitors, pricing, pain points, buying triggers, objections (`product-research` Steps 2-3)
// turbo
6. **Product Profile** — Compile: name, brand, category, niche, price range, key features, target audience, competitive landscape, landing page recommendations (`product-research` Step 3)
// turbo
7. **Color Extraction** — Extract dominant, secondary, and neutral tones from the product image for theme decisions (`product-research` Step 4)
// turbo
8. **Deep Pain Mining** — Identify 3 core emotional pains, hidden frustrations, fear/desire/frustration triggers (`product-research` Step 5)
// turbo
9. **Market Awareness Level** — Classify on Schwartz's 5 levels, determine messaging approach (`product-research` Step 6)
// turbo
10. **Market Sophistication** — Assess market maturity, define effective messaging vs. what to avoid (`product-research` Step 7)
// turbo
11. **Marketing Angles** — Generate 4+ angles: pain, result, social proof, offer, optional contrarian (`product-research` Step 8)
// turbo
12. **Offer Engineering** — Design: core offer, 2-3 bonuses, guarantee, urgency/scarcity (`product-research` Step 9)
// turbo
13. **Ad Hooks** — 5 scroll-stopping hooks: pattern interrupt, curiosity, problem, bold claim, story (`product-research` Step 10)
// turbo
14. **Creative Direction** — Visual style, best format, first-3-seconds concept, hero visual, color mood (`product-research` Step 11)
// turbo
15. **SEO Keyword Package** — Primary + secondary + LSI keywords, entity mapping, density targets, PAA opportunities (`seo-keyword-strategist`)

**Outputs passed forward:**
- ✅ Complete Product Profile
- ✅ Marketing Intelligence (pains, awareness, sophistication, angles, offer, hooks, creative direction)
- ✅ SEO keyword package (primary, secondary, LSI, entities)
- ✅ Product colors for theming

**Gate:** Present the Product Profile + Marketing Intelligence to the user for confirmation before proceeding.

---

## PHASE 3 — MARKETING STRATEGY

> **Role:** STRATEGY — Define how to sell this product visually and verbally.

**Skills:** `ad-creative-strategy`, `conversion-copywriting`

// turbo
16. **Angle Prioritization** — Score all angles on emotional strength, urgency, clarity. Select TOP 2 for visuals. Classify each image as Ad Creative / Landing Image / Both. Define visual style: UGC / Studio / Hybrid (`ad-creative-strategy` Step 1)
// turbo
17. **Image Strategy Briefs** — For each planned visual: goal, angle, emotion, big idea, core message, classification (`ad-creative-strategy` Step 2)
// turbo
18. **Image Type Planning** — Plan 4 mandatory types: Scroll Stopper, Problem vs Solution, Real Use Case, Result Image (`ad-creative-strategy` Step 3)
// turbo
19. **Copy Strategy** — Apply `conversion-copywriting` persuasion structure:
   - Hero Promise (headline + sub-headline + CTA)
   - Problem Visualization (real-life frustration)
   - Solution Introduction (simplicity, speed, reliability)
   - Feature → Benefit translations (never features alone)
   - Real Life Use Cases (help reader imagine using it)
   - Social Proof format (scenario + benefit + emotion)
   - Offer Stack copy (price, included, guarantee, bonuses)
   - FAQ answers (address real objections)

**Outputs passed forward:**
- ✅ Prioritized angles (top 2 for visuals)
- ✅ Image strategy briefs per visual
- ✅ Image generation plan (4 types with classifications)
- ✅ Complete copy strategy (section-by-section landing page text)

---

## PHASE 4 — SEO FOUNDATION

> **Role:** STRATEGY — Build the SEO skeleton before writing HTML.

**Skills:** `seo-structure-architect`, `seo-meta-optimizer`

// turbo
20. **Heading Hierarchy** — Build the H1 → H2 → H3 tree. One H1 per page. H2s for main sections with keyword variations. Question-based H3s for FAQ snippet eligibility (`seo-structure-architect`)
// turbo
21. **Schema Markup** — Prepare JSON-LD for: `Product` schema, `FAQPage` schema, `AggregateRating` if applicable, `BreadcrumbList` (`seo-structure-architect`)
// turbo
22. **Featured Snippet Optimization** — Format FAQ answers for paragraph snippets (40-60 words), comparison data for table snippets (`seo-structure-architect`)
// turbo
23. **Meta Package** — Generate 3-5 variations of: meta title (50-60 chars, primary keyword first 30 chars), meta description (150-160 chars, CTA + benefit), URL slug (under 60 chars) (`seo-meta-optimizer`)

**Outputs passed forward:**
- ✅ Complete heading hierarchy (H1-H3)
- ✅ JSON-LD schema blocks
- ✅ Snippet-optimized content formats
- ✅ Meta title, description, URL slug (selected best variation)

---

## PHASE 5 — DESIGN SYSTEM

> **Role:** DESIGN — Define the visual language before building any HTML.

**Skills:** `landing-page-design`

// turbo
24. **Theme Selection** — Choose dark / light / warm based on product category and extracted colors. Map extracted product colors to `--accent` and `--accent-dark` CSS variables (`landing-page-design`)
// turbo
25. **Typography Selection** — Choose heading, body, and accent fonts. Define scale per element: hero headline, section title, eyebrow, body, CTA (`landing-page-design`)
// turbo
26. **CTA Design** — Define primary CTA style: color, radius, padding, hover effect. Define CTA copy (action verbs). Plan 3 CTA placements: hero, mid-page, final offer (`landing-page-design`)
// turbo
27. **Visual Polish Rules** — Noise overlay opacity, border-radius tokens, SVG icon system (Lucide/Feather), responsive breakpoints, mobile rules (`landing-page-design`)

**Outputs passed forward:**
- ✅ `data-theme` value + CSS variable overrides
- ✅ Font stack + size scale
- ✅ CTA component spec
- ✅ Visual polish rules

---

## PHASE 6 — STRUCTURE & SECTIONS

> **Role:** DESIGN — Plan exactly which sections to build and in what order.

**Skills:** `landing-page-structure`, `landing-page-sections`

// turbo
28. **Structure Selection** — Based on product category, choose the matching landing page structure: Tech, Fashion/Artisan, Beauty, or Lead Gen. Apply category-specific section order (`landing-page-structure`)
// turbo
29. **Slot 6 Decision** — Classify product → select conditional section: Before & After, Lifestyle Showcase, Craftsmanship, or Use Cases (`landing-page-sections`)
// turbo
30. **Slot 5.5 Decision** — Include Comparison section only if product replaces a manual/inferior method. Skip for aesthetic products (`landing-page-sections`)
// turbo
31. **Section-by-Section Plan** — For each section (Hero → Proof Bar → Problem → Solution → Features → Comparison? → Slot 6 → Social Proof → Guarantee → Offer → FAQ → Footer CTA), define: purpose, copy from Phase 3, image needed (yes/no, original vs generated), layout pattern (`landing-page-sections`)

**Outputs passed forward:**
- ✅ Final section plan with order, content, and image decisions
- ✅ Per-section image strategy (original / generate / none)

---

## PHASE 7 — VISUAL GENERATION

> **Role:** GENERATION — Create photorealistic images with strict product identity preservation.

**Skills:** `ugc-image-generation`, `ad-creative-strategy` (Steps 4-8), `product-image-safety` (verification)

> **⚠️ GENERATION PRIORITY ORDER (from `product-image-safety`):**
> 1. **Use original product image directly** (safest — for hero, features, offer)
> 2. **Composite original product into generated scene** (safe — generate scene without product, then integrate via CSS)
> 3. **Full AI generation with Identity Lock** (risky — only when hand interaction or unique angle required, verify strictly)

// turbo
32. **Confirm Prerequisites** — Verify: Product Identity Lock exists, Image Strategy Briefs complete, section-level image decisions made
// turbo
33. **Generate Section Images** — For each section, apply the generation priority order:
   - **Hero:** Use original image directly — NEVER generate
   - **Problem:** Generate scenario image — NO product visible
   - **Solution:** Prefer original image — generate only if exact identity preservation succeeds
   - **Features:** Use icons or cropped details from original — NEVER generate
   - **Use Cases:** Generate scenes with Identity Lock — verify strictly, fallback to composite
   - **Lifestyle Showcase:** Generate aspirational shots with Identity Lock — verify strictly
   - **Comparison / Offer:** Reuse original product image — NEVER generate
   - **Before & After:** Before (no product), After (composite original product into bright scene)

   **If generating product-in-scene, every prompt must include:**
   - Part 1: Full Product Identity Lock (from `product-image-safety` Step 1)
   - Part 2: Scene description (environment, person, context, lighting)
   - Part 3: Strict Preservation Instruction (from `product-image-safety` Step 3)
   - Part 4: Photorealistic Integration rules (from `ad-creative-strategy` Step 4)
   - `ImagePaths` referencing the original product image

// turbo
34. **Hook Visual Definition** — For each generated image, define the first-3-seconds concept + why it stops scrolling + text overlay if any (`ad-creative-strategy` Step 5)
// turbo
35. **Creative Variations** — For key visuals, create Variation A (clean/safe for landing) and Variation B (emotional/aggressive for ads) (`ad-creative-strategy` Step 6)
// turbo
36. **Optimization Loop** — Evaluate each image against 3 checkpoints: Scroll Stop, 1-Second Clarity, Emotional Trigger. If 2+ fail → regenerate with adjusted prompt (`ad-creative-strategy` Step 7)
// turbo
37. **Identity Verification Gate** — Apply the 10-point rejection table from `product-image-safety` Step 5:
   - Silhouette, proportions, screen/display, buttons, chambers, nozzle/hose, branding, material, color zones, accessories
   - **If ANY check fails → REJECT immediately**
   - **Fallback:** Use original product image with CSS styling, or composite into the scene

**Outputs passed forward:**
- ✅ Generated images (4-6 max, each with clear strategic purpose)
- ✅ Image file paths for HTML integration
- ✅ Hook visual descriptions for ad use

**Gate:** No image ships without passing BOTH the Creative Optimization Loop AND the Identity Verification Gate. The customer must instantly recognize the SAME exact product from the original image — not a similar AI-generated variant.

**Budget:** 4-6 images maximum per landing page.

---

## PHASE 8 — BUILDER-COMPATIBLE HTML

> **Role:** INTEGRATION — Generate HTML/CSS/JS structured for LandingBuilder (GrapesJS).

**Skills:** `landing-builder-compat`, `landing-page-sections`

// turbo
38. **Output Structure** — Generate the landing page as a JSON-compatible package with 4 fields (`landing-builder-compat`):
   ```json
   {
     "html": "<body content HTML only — no <html>, <head>, <body> tags>",
     "css": "body-level CSS (themes, custom styles, animations)",
     "js": "body-level JavaScript (theme toggle, accordion, countdown)",
     "custom_head": "<link> tags for fonts, external styles"
   }
   ```
// turbo
39. **Apply Builder Rules** — Ensure:
   - No Tailwind/Alpine/jQuery includes (already loaded by system)
   - No inline `onclick` handlers (stripped on import)
   - No `document.write()`
   - All forms use `action="/api/forms/submit"` + `method="POST"`
   - All CTAs use `class="cta"` + `data-track="cta_[position]"` + `data-position="[section]"`
   - Cart buttons use `class="btn-add-cart"` + `data-product-label` + `data-price` + `data-product-id`
   - Countdown uses `class="countdown"` + `data-target`
   - All sections use `id="[section]"` + `data-section="[section]"`
   - Images use `alt` attributes, `loading="lazy"` for below-fold, optimized formats, under 500KB
   - Single `<h1>` per page
// turbo
40. **Thank You Page** — If applicable, generate a separate Thank You page with CRM element IDs (`crm-order-id`, `crm-fullname`, `crm-email`, `crm-phone`, `crm-total`, `crm-invoice-btn`)

**Outputs passed forward:**
- ✅ Builder-compatible JSON package (html + css + js + custom_head)
- ✅ Thank You page (if applicable)

---

## PHASE 9 — FRONTEND STYLING

> **Role:** INTEGRATION — Apply the Tailwind CSS design system to all components.

**Skills:** `frontend-tailwind-system`, `landing-page-design`

// turbo
41. **Tailwind Config** — Apply the design system tokens to `tailwind.config`: font families, color palette, border-radius tokens. Dark mode via `['selector', '[data-theme="dark"]']` (`frontend-tailwind-system`)
// turbo
42. **Component Styling** — Apply Tailwind patterns for each section:
   - Hero: split or centered layout with `clamp()` font sizing
   - Feature grid: 3-column responsive with icon containers
   - Testimonial cards: border, rating, quote, avatar
   - Guarantee card: centered, rounded, icon badges
   - CTA buttons: accent bg, uppercase tracking, hover translateY
   - FAQ accordion: toggle animation
// turbo
43. **Responsive Rules** — Apply breakpoints:
   - Default (mobile): single column, full-width CTAs, touch targets ≥ 48px
   - `sm:` / `md:` (tablet): 2-column grids, inline CTAs
   - `lg:` / `xl:` (desktop): 3-column grids, max-width containers
// turbo
44. **Dark Mode** — Add `dark:` counterparts for all themed elements. Ensure theme toggle button is functional.

**Outputs passed forward:**
- ✅ Fully styled, responsive landing page
- ✅ Working theme toggle

---

## PHASE 10 — SEO CONTENT & AUTHORITY PASS

> **Role:** VALIDATION — Quality-check all content for SEO and E-E-A-T before shipping.

**Skills:** `seo-content-optimizer`, `seo-authority-builder`

// turbo
45. **Content Quality Audit** — Review all landing page copy for (`seo-content-optimizer`):
   - Keyword density (0.5-1.5% for primary, natural secondary placement)
   - Primary keyword in first 100 words
   - Semantic variations throughout (not exact-match repetition)
   - Readability: grade 8-10, short paragraphs, bullet points
   - E-E-A-T signals: data sources, specificity, authority indicators
// turbo
46. **E-E-A-T Enhancement** — Score and enhance (`seo-authority-builder`):
   - **Experience:** Ensure testimonials include real scenarios, product-in-use images
   - **Expertise:** Feature specifications are accurate, benefit claims are specific
   - **Authority:** Proof bar includes credible signals (press logos, certifications, stats)
   - **Trust:** Guarantee section is prominent, contact info accessible, return policy clear
// turbo
47. **Schema Verification** — Validate all JSON-LD schema blocks match actual page content. FAQ schema questions match visible FAQ section. Product schema matches real product data.

**Outputs passed forward:**
- ✅ SEO-optimized content (density, placement, variations)
- ✅ E-E-A-T compliance (scored and enhanced)
- ✅ Validated schema markup

---

## PHASE 11 — SECURITY & FINAL VALIDATION

> **Role:** VALIDATION — Last gate before delivery. Nothing ships without passing.

**Skills:** `frontend-security`, `seo-audit` (lightweight), `landing-builder-compat` (final check)

// turbo
48. **Security Scan** — Check all generated code for (`frontend-security`):
   - No `innerHTML` with dynamic content → use `textContent`
   - No `document.write()`
   - No inline `onclick` handlers → use `addEventListener`
   - All external links have `rel="noopener noreferrer"`
   - All forms validate inputs
   - No hardcoded secrets or tokens
// turbo
49. **SEO Health Check** — Quick audit of the finished page (`seo-audit` — lightweight pass):
   - Single H1 ✓
   - Heading hierarchy intact (no skipped levels) ✓
   - Meta title ≤ 60 chars ✓
   - Meta description ≤ 160 chars ✓
   - All images have `alt` attributes ✓
   - Schema markup valid ✓
   - No orphaned links ✓
// turbo
50. **Builder Compatibility Final Check** — Verify the JSON package (`landing-builder-compat`):
   - `html` field contains body content only
   - No duplicate framework includes
   - All forms use correct `action` endpoint
   - All tracking attributes present on CTAs
   - Images optimized and under 500KB
// turbo
51. **Conversion Checklist** — Final human-verifiable checklist:
   - [ ] CTA appears 3 times: hero, mid-page, final offer
   - [ ] Micro-trust below every CTA
   - [ ] No navigation menu — CTA is the only exit
   - [ ] No external links — everything leads to conversion
   - [ ] FAQ answers real objections, not generic questions
   - [ ] Testimonials include scenario + benefit + emotion
   - [ ] Offer stack clearly communicates value
   - [ ] Mobile version tested (full-width CTAs, stacked grids)

---

## FINAL OUTPUT

Deliver in this exact order:

| # | Deliverable | Source Phase |
|---|---|---|
| 1 | Product Identity Lock | Phase 1 |
| 2 | Product Profile + Marketing Intelligence | Phase 2 |
| 3 | SEO Keyword Package | Phase 2 |
| 4 | Marketing Strategy (angles, copy, offer, hooks) | Phase 3 |
| 5 | SEO Foundation (headings, schema, meta tags) | Phase 4 |
| 6 | Design System (theme, typography, CTA spec) | Phase 5 |
| 7 | Section Plan (with image decisions) | Phase 6 |
| 8 | Generated Images (with hook visual descriptions) | Phase 7 |
| 9 | Builder-Compatible JSON (html + css + js + custom_head) | Phase 8-9 |
| 10 | Validation Report (SEO + security + conversion checklist) | Phase 10-11 |

---

## ON-CALL: Post-Launch Diagnostics

**Skill:** `seo-incident-response`

This skill is NOT part of the generation workflow. Use it only when:
- Organic traffic drops after the landing page is live
- Rankings decline unexpectedly
- A core Google update affects performance

When triggered, follow the `seo-incident-response` triage → classify → investigate → hypothesize → recover workflow.

---

## CRITICAL RULES

1. **Every phase passes data forward** — no resets, no re-research, no lost context
2. **Fresh Identity Lock per task** — never reuse from a previous generation
3. **Original product image preferred** for hero and key product shots
4. **Failsafe** → original image over altered generation, always
5. **Adaptive structure** → sections match the product category, not a one-size template
6. **No generic outputs** — every element reflects this specific product
7. **Theme consistency** — one palette from `landing-page-design`, no mixing
8. **Builder compatibility** — output must import cleanly into LandingBuilder/GrapesJS
9. **Security first** — no XSS vectors, no inline handlers, no unsafe DOM manipulation
10. **This file orchestrates** — detailed rules live in each skill file
